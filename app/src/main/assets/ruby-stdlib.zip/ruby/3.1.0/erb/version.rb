# frozen_string_literal: true
class ERB
  VERSION = '2.2.3'
  private_constant :VERSION
end
