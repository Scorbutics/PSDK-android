begin
  require 'rubygems'
  Dir.chdir ENV["PSDK_ANDROID_FOLDER_LOCATION"] + "/PSDK-Linux_24.46/"
  require './Game.rb'
rescue => error
  puts error
end

