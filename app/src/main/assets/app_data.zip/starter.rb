begin
  require 'rubygems'
  Dir.chdir "/storage/58F4-1915/PSDK-Linux_24.46/"
  require './Game.rb'
rescue => error
  puts error
end

