module DidYouMean
  VERSION = "1.6.1".freeze
end
