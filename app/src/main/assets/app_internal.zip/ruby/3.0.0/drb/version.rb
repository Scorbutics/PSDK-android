module DRb
  VERSION = "2.0.4"
end
