module DidYouMean
  VERSION = "1.5.0"
end
