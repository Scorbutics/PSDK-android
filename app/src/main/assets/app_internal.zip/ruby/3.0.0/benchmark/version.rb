module Benchmark
  VERSION = "0.1.1"
end
