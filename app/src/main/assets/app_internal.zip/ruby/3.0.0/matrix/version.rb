# frozen_string_literal: true

class Matrix
  VERSION = "0.3.1"
end
