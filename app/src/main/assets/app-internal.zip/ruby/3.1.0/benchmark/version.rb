# frozen_string_literal: true
module Benchmark
  VERSION = "0.2.0"
end
