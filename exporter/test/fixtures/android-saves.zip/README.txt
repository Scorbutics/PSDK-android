Saves of a PSDK game, exported to move them to another device.

On Android: in the game, open the gamepad's tools button > Settings,
then Saves > Import saves, and pick this file.

On a computer: from the game's folder, run
    ruby save_transfer.rb import <this file>
or unzip this file into the game's folder (where Game.rb is), letting it
replace the files already there. When the game's folder is read-only,
the game keeps its saves in %APPDATA%\.<game title>\ (Windows) or
~/.<game title>/ instead: unzip it there.

psdk_saves.json and README.txt are not needed by the game.
